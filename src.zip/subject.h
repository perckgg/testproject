#include"header.h"
#define SUBJECT_CODE_SIZE = 4
#define SUBJECT_NAME_SIZE = 30
class subjectname
{
   char subject_id[4]; //SUBJECT CODE
   char subject_name[30];//SUBJECT NAME
   public:
   //FUNCTION TO ENTER DATA OF SUBJECTS
   void enter()
   {
      cout<<"\nEnter the subject name :  ";
      cin >> subject_name;
      cout<<"\nEnter the subject ID : ";
      cin >> subject_id;
   };
   //FUNCTION TO DISPLAY DATA OF SUBJECTS
   void show()
   {
      cout<<"\nSubject ID is  :  "<<subject_id;
      cout<<"\nSubject Name is  :  "<<subject_name;
   }
   //FUNCTION TO ADD NEW SUBJECTS
   void modify(){
      fstream f("SUBJECT.DAT",ios :: app | ios :: binary);
      subjectname s1;
      int n;
      cout<<"\nenter the number of enteries : " ;
      cin>>n;
      for(int i = 0; i < n; i++){
        s1.enter();
        f.write((char*)&s1,sizeof(s1));
      }
      f.close();
   };
   //FUNCTION TO COPY SUBJECT NAME ACCORDING TO SUBJECT CODE   
   friend void subName_to_subID(char s1[4], char s2[30]);
};

