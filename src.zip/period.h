#include"header.h"
class period
{
   int classno;//CLASS NUMBER
   int n;      //NUMBER OF SUBJECTS
   char section;//SECTION OF CLASS
   subject s[10];
   public:
   //CONSTRUCTOR
   period()
   {
     n=0;
   }
   //FUNCTION TO ENTER THE DATA
   void enter(int n1);
   //FUNCTION TO DISPLAY DATA
   void show();
   //FUNCTION TO ADD NEW CLASS
   void add();
   //FUNCTION TO RETURN NUMBER OF PERIODS AND SUBJECT CODE
   void return1(char s1[3],int & n1,int m)
   {
      strcpy(s1,s[m-1].sub_ID);
      n1=s[m-1].noofperiods;
   }
   //FUNCTION TO RETURN THE CLASS NUMBER
   int classno1()
   {
      return classno;
   }
   //FUNCTION TO RETURN SECTION
   char section1()
   {
      return section;
   }
   //FUNCTION TO RETURN NUMBER OF SUBJECTS
   int return3()
   {
     return n;
   }
   //FUNCTION TO ADD NEW CLASS
   void modify();
};
void period :: show()
{
   int j=0;
   for(j=0;j<n;j++)
   {
       cout<<"\nClass is  :  "<<classno;
       cout<<"\nSection is : "<<section;
       cout<<"\nNumber of periods is  : "<<s[j].noofperiods;
       cout<<endl<<"Subject ID is : "<<s[j].sub_ID;
       getch();
   }
}

void period :: enter(int n1)
{
   int j;
   cout<<"\nEnter the class :  ";
   cin>>classno;
   cout<<"\nEnter the section :  ";
   cin>>section;
   n=n1;
   for(j=0;j<n;j++)
     {
       cout<<"\nEnter the subject ID ";
       cin >> s[j].sub_ID;
       cout<<"\nEnter the number of periods : ";
       cin>>s[j].noofperiods;
     }
}
void period :: add()
{
  fstream f("PERIOD.DAT",ios :: app | ios :: binary);
  period p;
  int n,j;
  cout<<"\nEnter the number of period to add : ";
  cin>>n;
  for(int i = 0; i < n; i++)
  {
     cout<<"\nEnter the number of subjects : ";
     cin>>j;
     p.enter(j);
     f.write((char*)&p,sizeof(p));
  }
  f.close();
}
void period :: modify()
{
   int classno1;
   char section1, sub[30];
   fstream f("PERIOD.DAT", ios :: in | ios :: out | ios :: binary);
   period p;
   cout<<"\nEnter the class : ";
   cin>>classno1;
   cout<<"\nEnter the section : ";
   cin>>section1;
   cout<<"\nEnter the subject ID : ";
   cin >> sub;
   f.read((char*)&p,sizeof(p));
   while(!f.eof())
   {
      if(p.classno1()==classno1 && section1==p.section1())
      {
	break;
      }
      f.read((char*)&p,sizeof(p));
   }
   for(int i=0;i<n;i++)
   {
      if(strcmpi(sub,s[i].sub_ID)==0)
      {
	 cout<<"\nEnter the number of period : ";
	 cin>>s[i].noofperiods;
       }
   }
   f.seekg(-sizeof(p),ios :: cur);
   f.write((char*)&p,sizeof(p));
   f.close();
}