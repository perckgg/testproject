#pragma once
#include"header.h"
#define TEACHER_ID_SIZE = 3
#define TEACHER_NAME_SIZE = 30
#define SUBJECT_ID_SIZE = 3
class teacher
{
   char teacher_id[3];       //TEACHER CODE
   char teachername[30];//TEACHER NAME
   char subject_id[3];//subject_id OF TEACHER
   int d;
   public:
   teacher(){
      d = 0;
   }
   //FUNCTION TO ENTER DATA OF TEACHERS
   void enter()
   {
      cout<<"\nTeacher Name is : ";
      cin >> teachername;
      cout<<"\nTeacher ID is : ";
      cin >> teacher_id;
      cout<<"\nSubject ID is : ";
      cin >> subject_id;
   };
   //FUNCTION TO DISPLAY DATA OF TEACHERS
   void show()
   {
      cout<<"\nTeacher name is  :  "<<teachername;
      cout<<"\nSubject ID : "<<subject_id;
      cout<<"\nTeacher ID is : "<<teacher_id;
   }
   //FUNCTION TO ADD NEW TEACHERS
   void modify()
   {
        fstream f("TEACHER.DAT",ios :: app | ios :: binary);
        teacher t;
        int n;
        cout<<"\nEnter the number of Teacher : ";
        cin>>n;
        for(int i = 0; i < n; i++)
        {
             t.enter();
             f.write((char*)&t,sizeof(t));
        }
        f.close();
   };
};
