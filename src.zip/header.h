#pragma once    
#include<iostream>
#include<conio.h>
#include<fstream>
#include<stdio.h>
#include<string.h>
#include<iomanip>
#include<stdlib.h>
using namespace std;
struct classandsection{
   int classno;
   char section;
};
struct  subject
{
   char sub_ID[4];
   int noofperiods;
};
struct subject2
{
  char sub_ID[4];//SUBJECT CODE
  int n[6];       //NUMBER OF PERIODS IN EACH DAY
  int d;          //NUMBER OF PERIODS IN A WEEK
  int m;          //VARIABLE USED FOR COMPAIRING NUMBER OF PERIODS
};
//STRUCTURE TO DATABASE OF SUBJECT AND TEACHERS
struct subject3
{
  char scode[4];//SUBJECteacher_id
  char teacher_id[4];//TEACHERCODE
  char subname[30];//SUBJECTNAME
};

int random(int n)
{
  int r;
  r=rand()%n;
  return r;
}