#include<graphics.h>
#include"header.h"
#include"subject.h"
#include"period.h"
#include"teacher.h"
#include"subjectteacher.h"
void teacher_to_subject(char s[4],char t[4])
{
   fstream f("SUBJECTTEACHER.DAT",ios :: in | ios :: binary);
   subjectteacher s1;
   f.read((char*)&s1,sizeof(s1));
   while(!f.eof())
   {
      if(strcmpi(s,s1.sub_ID)==0)
      {
	strcpy(t,s1.teacher_id);
	break;
      }
      f.read((char*)&s1,sizeof(s1));
   }
   f.close();
}
void subName_to_subID(char s1[4],char s2[30]){
   fstream f("SUBJECT.DAT",ios :: in|ios :: binary);
   subjectname s;
   f.read((char*)&s,sizeof(s));
   while(!f.eof()){
      if(strcmpi(s1,s.subject_id)==0){
         strcpy(s2,s.subject_name);
      }
      f.read((char*)&s,sizeof(s));
   }
}
void display(int classno1,char section1,int classno2,char section2,int classno3,char section3)
{
  cleardevice();
  fstream f("PERIOD.DAT",ios :: in | ios :: binary);
  int i,j,k,c,l,l2,l3,m1,m2,m3,n1,n2,n3;
  /*n1,n2,n3 :- VARIABLES FOR STORING NUMBER OF SUBJECTS
    m1,m2,m3 :- RANDOM VARIABLES USED FOR GENERATING TIMETABLE*/
  subject2 s1[10],s2[10],s3[10];
  subject3 f1[6][8],f2[6][8],f3[6][8];
  period p,p1,p2,p3;
  f.read((char*)&p,sizeof(p));
  while(!f.eof())
   {
    //COMPAIRING THE CLASS NUMBER AND SECTION
    if(p.classno1()==classno1 && section1==p.section1())
     {
      p1=p;
     }
    else if(p.classno1()==classno2 && section2==p.section1())
    {
      p2=p;
    }
    else if(p.classno1()==classno3 && section3==p.section1())
    {
      p3=p;
    }
    f.read((char*)&p,sizeof(p));
  }
  f.close();
  //RETURNING NUMBER OF SUBJECTS
  n1=p1.return3();
  n2=p2.return3();
  n3=p3.return3();
  //LOOP FOR ENTERING DATA FROM OBJECT OF CLASS PERIOD
  for(i=0;i<n1;i++)
  {
     p1.return1(s1[i].sub_ID,s1[i].d,i+1);
     s1[i].m=0;
     for(j=0;j<6;j++)
      {
	s1[i].n[j]=0;
      }
  }
  //LOOP FOR ENTERING DATA FROM OBJECT OF CLASS PERIOD
  for(i=0;i<n2;i++)
  {
     p2.return1(s2[i].sub_ID,s2[i].d,i+1);
     s2[i].m=0;
     for(j=0;j<6;j++)
      {
	s2[i].n[j]=0;
      }

  }
  //LOOP FOR ENTERING DATA FROM OBJECT OF CLASS PERIOD
  for(i=0;i<n3;i++)
  {
     p3.return1(s3[i].sub_ID,s3[i].d,i+1);
     s3[i].m=0;
     for(j=0;j<6;j++)
      {
	s3[i].n[j]=0;
      }

  }
  rand();
    m1 = random(n1);
    m2 = random(n2);
    m3 = random(n3);
  //LOOP FOR GENERATING TIME TABLE
  for(i=0;i<6;i++)
  {
    for(j=0;j<8;j++)
    {
      //CHECKING THE CONDITION FOR NUMBER OF PERIODS IN A WEEK
      if(s1[m1].m==s1[m1].d)
	 {
	  l: m1=random(n1);
	 }
	//CHECKING THE CONDITION FOR NUMBER OF PERIODS IN A WEEK
	if(s1[m1].n[i]>=0&&s1[m1].n[i]<2)
	{
	   //COPYING THE SUBJECT CODE
	   strcpy(f1[i][j].scode,s1[m1].sub_ID);
	   //COPYING THE TEACHER CODE
	   teacher_to_subject(f1[i][j].scode,f1[i][j].teacher_id);
	   //COPYING THE SUBJECT NAME
	   subName_to_subID(f1[i][j].scode,f1[i][j].subname);
	   (s1[m1].n[i])++;
	   (s1[m1].m)++;
	   m1=random(n1);
	}
	else
	{
	 goto l;
	}
      //CHECKING THE CONDITION FOR NUMBER OF PERIODS IN A WEEK
      if(s2[m2].m==s2[m2].d)
	{
	l2 : m2=random(n2);
	}
	//CHECKING THE CONDITION FOR NUMBER OF PERIODS IN A DAY
	if(s2[m2].n[i]>=0&&s2[m2].n[i]<2)
	{
	    //COPYING THE SUBJECT CODE
	    strcpy(f2[i][j].scode,s2[m2].sub_ID);
	    //COPYING THE TEACHER CODE
	    teacher_to_subject(f2[i][j].scode,f2[i][j].teacher_id);
	    //COPYING THE SUBJECT NAME
	    subName_to_subID(f2[i][j].scode,f2[i][j].subname);
	    (s2[m2].n[i])++;
	    (s2[m2].m)++;
	    //CHECKING CONDITION FOR SAME TEACHER
	    if(strcmpi(f1[i][j].teacher_id,f2[i][j].teacher_id)==0)
	      goto l2;
	    m2=random(n2);
	}
	else
	{
	   goto l2;
	}
	//CHECKING THE CONDITION FOR NUMBER OF PERIODS IN A WEEK
	if(s3[m3].m==s3[m3].d)
	{
	l3: m3=random(n3);
	}
	//CHECKING THE CONDITION FOR NUMBER OF PERIODS IN A DAY
	if(s3[m3].n[i]>=0&&s3[m3].n[i]<2)
	{
	    //COPYING THE SUBJECT CODE
	    strcpy(f3[i][j].scode,s3[m3].sub_ID);
	    //COPYING THE TEACHER CODE
	    teacher_to_subject(f3[i][j].scode,f3[i][j].teacher_id);
	    //COPYING THE SUBJECT NAME
	    subName_to_subID(f3[i][j].scode,f3[i][j].subname);
	   (s3[m3].n[i])++;
	   (s3[m3].m)++;
	   //CHECKING CONDITION FOR SAME TEACHER
	  if(strcmpi(f1[i][j].teacher_id,f3[i][j].teacher_id)==0)
	     goto l3;
	   m3=random(n3);
	}
	else
	{
	   goto l3;
	}
      }

  }
      char string[10];
      //put "CLASS:" into string1
      char string1[10]="CLASS:";
    outtextxy(2,5,string1);
      itoa(classno1,string , 10);
      //CONVERTING AN INTEGER DATA TYPE TO A STRING DATA TYPE
      outtextxy(100,5,string);
      string[0]=section1;
      string[1]='\0';
      outtextxy(120,5,string);
      int r=0,s=80,size=2,t;
      settextstyle(1,0,size);
      setcolor(RED);
      /*CHANGING COLOUR OF FONT TO RED*/
      t=67;
      i=0;
      for(i=0;i<9;i++)//LOOP FOR DISPLAYING TABLE
	 {
	 line(t,54,t,386);
	 t=t+67;
	 }
      t=55;
      for(i=0;i<7;i++)
	 {
	 line(0,t,605,t);
	 t=t+55;
	 }
     char string2[10]="MON";
     char string3[10]="TUE";
        char string4[10]="WED";
        char string5[10]="THU";
        char string6[10]="FRI";
        char string7[10]="SAT";
      outtextxy(2,80,string2 );
      outtextxy(2,130,string3);
      outtextxy(2,180,string4);
      outtextxy(2,230,string5);
      outtextxy(2,280,string6);
      outtextxy(2,330,string7);
      for(i=0;i<6;i++)
	{
	  r=69;
	  for(j=0;j<8;j++)
	    {
	     outtextxy(r,s,f1[i][j].subname );
	     r=r+69;
	    }
	  s=s+50;
	}
      getch();
      cleardevice();
      char string8[10]="CLASS:";
      outtextxy(2,5,string8);
      itoa(classno2,string , 10);
      //CONVERTING AN INTEGER DATA TYPE TO A STRING DATA TYPE
      outtextxy(100,5,string);
      string[0]=section2;
      string[1]='\0';
      outtextxy(129,5,string);
      r=0;
      s=80;
      settextstyle(1,0,size);
      setcolor(RED);
      /*CHANGING COLOUR OF FONT TO RED*/
      t=67;
      i=0;
      for(i=0;i<9;i++)//LOOP FOR DISPLAYING TABLE
	 {
	  line(t,54,t,386);
	  t=t+67;
	 }
      t=55;
      for(i=0;i<7;i++)
	 {
	  line(0,t,605,t);
	  t=t+55;
	 }
     char string9[10]="MON";
     outtextxy(2,80,string9 );
     char string10[10]="TUE";
     outtextxy(2,130,string10);
     char string11[10]="WED";
     outtextxy(2,180,string11);
     char string12[10]="THU";
     outtextxy(2,230,string12);
     char string13[10]="FRI";
     outtextxy(2,280,string13);
     char string14[10]="SAT";
     outtextxy(2,330,string14);
     for(i=0;i<6;i++)
     {
	 r=69;

	for(j=0;j<8;j++)
	{
	   outtextxy(r,s,f2[i][j].subname );
	   r=r+69;
	}
	s=s+50;
     }
     getch();
     cleardevice();
     outtextxy(2,5,"\nCLASS IS : ");
     itoa(classno3,string , 10);
     //CONVERTING AN INTEGER DATA TYPE TO A STRING DATA TYPE
     outtextxy(100,5,string);
     string[0]=section3;
     string[1]='\0';
     outtextxy(129,5,string);
     r=0;
     s=80;
     settextstyle(1,0,size);
     setcolor(RED);
     /*CHANGING COLOUR OF FONT TO RED*/
     t=67;
     i=0;
     for(i=0;i<9;i++)   //LOOP FOR DISPLAYING TABLE
	{
	line(t,54,t,386);
	t=t+67;
	}
     t=55;
     for(i=0;i<7;i++)
	{
	line(0,t,605,t);
	t=t+55;
	}
     outtextxy(2,80,"MON" );
     outtextxy(2,130,"TUE");
     outtextxy(2,180,"WED");
     outtextxy(2,230,"THU");
     outtextxy(2,280,"FRI");
     outtextxy(2,330,"SAT");
     for(i=0;i<6;i++)
	{
	 r=69;
	 for(j=0;j<8;j++)
	  {
	   outtextxy(r,s,f3[i][j].subname );
	   r=r+69;
	  }
	 s=s+50;
	}
     getch();
     cleardevice();

}
int main()
{
 int gdriver = DETECT, gmode, errorcode;
 int x,y;
 int midx,midy;
 /* initialize graphics and local variables */
 initgraph(&gdriver, &gmode, "/BGI");
 /* read result of initialization */
 errorcode = graphresult();
 if (errorcode != grOk)  /* an error occurred */
     {
      printf("Graphics error: %sn", grapherrormsg(errorcode));
      printf("Press any key to halt:");
      getch();
      exit(1); /* terminate with an error code */
      closegraph();
     }
 cleardevice();
 int size=5;
 settextstyle(1,0,size);
 setcolor(RED);
 /*CHANGING COLOUR OF FONT TO RED*/
 setbkcolor(CYAN);
 /*CHANGING BACKGROUND TO CYAN COLOUR*/
 outtextxy(220,50," WELCOME " );
 outtextxy(320,150,"TO");
 outtextxy(200,250," TIMETABLE ");
 outtextxy(210,350,"GENERATOR ");
 size=2;
 settextstyle(1,0,size);
 outtextxy(100,450,"MADE BY ->  ");
 outtextxy(250,450,"SOMIL JAIN");
 getch();
 cleardevice();
 int n=1;
 while(n!=6)
 {
      size=1;
      settextstyle(1,0,size);
      setcolor(WHITE);
      /*CHANGING COLOUR OF FONT TO WHITE*/
      outtextxy(0, 10 ,"ENTER YOU CHOICE :" );
      outtextxy(0, 30 ,"1. ADD SUBJECT");
      outtextxy(0, 50 ,"2. ADD TEACHERS ");
      outtextxy(0, 70 ,"3. ADD CLASS ");
      outtextxy(0, 90 ,"4. MODIFY PERIOD");
      outtextxy(0,110 ,"5. GENERATE TIMETABLE");
      outtextxy(0,130 ,"6. EXIT ");
      cin>>n;
      if(n==1)
      {
	 cleardevice();
	 subjectname s;
	 s.modify();
	 //MEMBER FUNCTION modify OF CLASS subjectname TO ADD SUBJECT
      }
      else if(n==2)
      {
	cleardevice();
	teacher t;
	t.modify();
	//MEMBER FUNCTION modify OF CLASS teacher TO ADD TEACHERS
      }
      else if(n==3)
      {
	 cleardevice();
	 period p;
	 p.add();
	 //MEMBER FUNCTION OF CLASS period TO ADD CLASS
      }
      else if(n==4)
      {
	 cleardevice();
	 period p;
	 p.modify();
	 //MEMBER FUNCTION OF CLASS period TO  MODIFY PERIOD
      }
      else if(n==5)
      {
	 cleardevice();
	 int c1,c2,c3;
	 char s1,s2,s3;
	 size=1;
	 setbkcolor(BLACK);
	 /*CHANGING BACKGROUND TO BLACK COLOUR*/
	 settextstyle(1,0,size);
	 setcolor(RED);
	 /*CHANGING COLOUR OF FONT TO RED*/
	 outtextxy(0,  4,"ENTER THE CLASS :  " );
	 cout<<"\n";
	 cin>>c1;
	 outtextxy(0, 40,"ENTER THE SECTION :  :  ");
	 cout<<"\n";
	 cin>>s1;
	 outtextxy(0, 76,"ENTER THE CLASS :   ");
	 cout<<"\n";
	 cin>>c2;
	 outtextxy(0,122,"ENTER THE SECTION :  ");
	 cout<<"\n";
	 cout<<"\n";
	 cin>>s2;
	 outtextxy(0,170,"ENTER THE CLASS :  ");
	 cout<<"\n";
	 cout<<"\n";
	 cin>>c3;
	 outtextxy(0,204,"ENTER THE SECTION :  ");
	 cout<<"\n";
	 cin>>s3;
	 display(c1,s1,c2,s2,c3,s3);
      }
      cleardevice();
   }
 size=8;
 settextstyle(1,0,size);
 outtextxy(75,204,"THANK YOU");
 getch();
}