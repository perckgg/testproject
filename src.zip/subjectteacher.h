#pragma once
#include"header.h"
#include"teacher.h"
class subjectteacher{
   classandsection c[5];
   char teacher_id[4];//TEACHER CODE
   char sub_ID[4];//SUBJECT CODE
   int i;//NUMBER OF CLASSES THAUGHT BY TEACHER
   public:
   //FUNCTION TO ENTER THE DATA
   void enter();
   //FUNCYION TO DISPLAY DATA
   void show();
   //FUNCTION ADD NEW TEACHER
   void add();
   //FUNCTION TO MODIFY DETAILS OF TEACHER
   void modify();
   //FUNCTION TO RETURN TEACHER CODE ACCORDING TO SUBJECT CODE
   friend void teacher_to_subject(char s[4],char t[4]);
};
void subjectteacher :: show(){
   int n;
   cout<<"\nenter the number of enteries : ";
   cin>>n;
   for(i=0;i<n;i++){
      cout<<"\nclass is:  "<<c[i].classno;
      cout<<"section is: "<<c[i].section;
   }
   cout<<"\nteacher code is: "<<teacher_id;
   cout<<"\nsubject code is: "<<sub_ID;
}
void subjectteacher :: add(){
   fstream f("SUBJECTTEACHER.DAT",ios :: app | ios :: binary);
   subjectteacher s;
   int n;
   fstream f1("TEACHER.DAT",ios :: app | ios :: binary);
   teacher t;
   cout<<"\nenter the number of enteries : ";
   cin>>n;
   for(int i=0;i<n;i++){
      t.enter();
      s.enter();
      f1.write((char*)&t,sizeof(t));
      f.write((char*)&s,sizeof(s));
      f.close();
      f1.close();
   }
}

void subjectteacher :: enter()
{
   int n;
   cout<<"\nenter the number of enteries : ";
   cin>>n;
   for(i=0;i<n;i++)
   {
     cout<<"\nclass is  :  ";
     cin>>c[i].classno;
     cout<<"section is  : ";
     cin>>c[i].section;
   }
   cout<<"\nenter the sub_ID : ";
   cin >> sub_ID;
   cout<<"\nenter the teacher_id : ";
   cin >> teacher_id;
}
